from flaskr import app
app.run(debug=True)
